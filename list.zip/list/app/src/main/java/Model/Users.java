package Model;

public class Users {
    public int id;
    public int Index;
    public String Items,Category;

    public Users(int id, int index, String items, String category) {
        this.id = id;
        this.Index = index;
        this.Items = items;
       this.Category = category;


    }

    public Users() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIndex() {
        return Index;
    }

    public void setIndex(int index) {
        Index = index;
    }

    public String getItems() {
        return Items;
    }

    public void setItems(String items) {
        Items = items;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }
}
