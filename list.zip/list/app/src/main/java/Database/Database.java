package Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import Model.Users;

public class Database extends SQLiteAssetHelper {
    private static final String DB_NAME="Users.db";
    private static final int DB_VER=1;

    public Database(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }
    public List<Users> getUsers()
    {
        SQLiteDatabase db= getReadableDatabase();
        SQLiteQueryBuilder qb= new SQLiteQueryBuilder();

        String[] sqlSelect ={"Id","Items","Index","Category"};
        String tableName="Users";
        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlSelect,null,null,null,null,null);
        List<Users> result = new ArrayList<>();
        if(cursor.moveToFirst()){
            do {
                Users users = new Users();
                users.setId(cursor.getInt(cursor.getColumnIndex("Id")));
                users.setItems(cursor.getString(cursor.getColumnIndex("Items")));
                users.setIndex(cursor.getInt(cursor.getColumnIndex("Index")));
                users.setCategory(cursor.getString(cursor.getColumnIndex("Category")));
                result.add(users);
            }while (cursor.moveToNext());
        }
        return result;

    }
    public List<String> getItems()
    {
        SQLiteDatabase db= getReadableDatabase();
        SQLiteQueryBuilder qb= new SQLiteQueryBuilder();

        String[] sqlSelect ={"Items"};
        String tableName="Users";
        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlSelect,null,null,null,null,null);
        List<String> result = new ArrayList<>();
        if(cursor.moveToFirst()){
            do {
                result.add(cursor.getString(cursor.getColumnIndex("Items")));
            }while (cursor.moveToNext());
        }
        return result;
    }

    public List<Users> getUsersByItems (String items)
    {
        SQLiteDatabase db= getReadableDatabase();
        SQLiteQueryBuilder qb= new SQLiteQueryBuilder();

        String[] sqlSelect ={"Id","Items","Index","Category"};
        String tableName="Users";
        qb.setTables(tableName);
       // Cursor cursor = qb.query(db,sqlSelect,"Items = ?",new String[]{items},null,null,null);

        Cursor cursor = qb.query(db,sqlSelect,"Items LIKE ?",new String[]{"%"+items+"%"},null,null,null);
        List<Users> result = new ArrayList<>();
        if(cursor.moveToFirst()){
            do {
                Users users = new Users();
                users.setId(cursor.getInt(cursor.getColumnIndex("Id")));
                users.setItems(cursor.getString(cursor.getColumnIndex("Items")));
                users.setIndex(cursor.getInt(cursor.getColumnIndex("Index")));
                users.setCategory(cursor.getString(cursor.getColumnIndex("Category")));
                result.add(users);
            }while (cursor.moveToNext());
        }
        return result;
    }
}
