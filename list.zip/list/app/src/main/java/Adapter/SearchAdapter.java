package Adapter;


import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.list.R;

class SearchViewHolder extends RecyclerView.ViewHolder{
    public TextView Items,Index,Category;

    public SearchViewHolder( View itemView) {
        super(itemView);
        Items = (TextView)itemView.findViewById(R.id.item);
        Index = (Integer)itemView.findViewById(R.id.index);
        Category = (TextView)itemView.findViewById(R.id.category);

    }
}
public class SearchAdapter {
}
