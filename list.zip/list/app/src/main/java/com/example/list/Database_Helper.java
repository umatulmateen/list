package com.example.list;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database_Helper extends SQLiteOpenHelper {
    private static final String Db_Name = "Users.db";
    private static final String Db_Table = "Users_Table";


    private static final String ID = "ID";
    private static final String Name = "Name";

    private static final String Create_Table = "CREATE TABLE "+ Db_Table+ " ("+
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Name+ " TEXT " + ")";


    public Database_Helper(Context context)

    {
        super(context, "Users.db", null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Create_Table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ Db_Table);
        onCreate(db);

    }

    public boolean insertData(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Name, name);

        long result = db.insert(Db_Table, null,contentValues);
        return result != -1;

    }

    public Cursor viewData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from "+Db_Table;
        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }
}
